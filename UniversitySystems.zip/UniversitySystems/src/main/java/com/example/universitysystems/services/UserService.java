package com.example.universitysystems.services;

import com.example.universitysystems.entities.Roles;
import com.example.universitysystems.entities.Users;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;
import java.util.Optional;


public interface UserService extends UserDetailsService {
    Users getUserByEmail(String email);
    Users createUser(Users user);

    Users saveUser(Users users);

    List<Users> findAllUsers();

    List<Roles> findAllRoles();


    Users findById(Long id);



    Roles findRoleById(Long id);

    List<Users> findUserByUsername(String name);

    void deleteUser(Users user);
}
