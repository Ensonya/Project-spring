package com.example.universitysystems.controllers;

import com.example.universitysystems.entities.Roles;
import com.example.universitysystems.entities.Users;
import com.example.universitysystems.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class UserController {


    private UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }


    @GetMapping(value="/403")
    public String accessDenied(Model model){
        model.addAttribute("currentUser", getUserData());
        return "403";
    }

    @GetMapping(value = "/")
    public String login(Model model){
        model.addAttribute("currentUser", getUserData());
        return "login";
    }

    @GetMapping(value="/profile")
    @PreAuthorize("isAuthenticated()")
    public String profile(Model model){
        model.addAttribute("currentUser", getUserData());
        return "about";
    }

    @GetMapping(value = "/register")
    public String register(Model model){

        model.addAttribute("currentUser", getUserData());

        return "register";
    }

    @PostMapping(value="/register")
    public String toRegister(@RequestParam(name="user_email") String email,
                             @RequestParam(name="user_password") String password,
                             @RequestParam(name="re_user_password") String rePassword,
                             @RequestParam(name="user_full_name") String fullName){

        if(password.equals(rePassword)){
            Users newUser=new Users();

            newUser.setFullName(fullName);
            newUser.setPassword(password);
            newUser.setEmail(email);

            if(userService.createUser(newUser)!=null){
                return "redirect:/";
            }

        }

        return "redirect:/register?error";


    }

    @GetMapping(value="/logout")
    public String logout(Model model){
        model.addAttribute("currentUser", getUserData());
        return "login";
    }

    @GetMapping(value="/modify")
    public String modify(Model model){
       List<Users> usersList=userService.findAllUsers();

       model.addAttribute("currentUser", getUserData());
       model.addAttribute("users", usersList);

        return "modify";
    }

    @GetMapping(value = "/getAll")
    public List<Users> users(String name){
        name="b";
        return userService.findUserByUsername(name);
    }


    @GetMapping(value="/edituser/{id}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    public String edituser(Model model, @PathVariable(name="id") Long id){

        model.addAttribute("currentUser", getUserData());

        Users user = userService.findById(id);
        model.addAttribute("user", user);

        List<Roles> roles=userService.findAllRoles();
        model.addAttribute("roles", roles);

        return "edituser";
    }

    @PostMapping(value="/saveuser")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    public String saveUser(@RequestParam(name="id", defaultValue = "0") Long id,
                           @RequestParam(name="user_email", defaultValue = "0") String email,
                           @RequestParam(name="user_name", defaultValue = "No Item") String name,
                           @RequestParam(name="roles_id",defaultValue = "0") Long role_id){

        Users user=userService.findById(id);
        if(user!=null){

                Roles role =userService.findRoleById(role_id);
                if(role!=null) {
                    user.setFullName(name);
                    user.setEmail(email);
                    List<Roles> roles=new ArrayList<>();
                    roles.add(role);
                    user.setRoles(roles);
                    userService.saveUser(user);
                }

        }

        return "redirect:/edituser/"+id;
    }


    @PostMapping(value="/deleteitem")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    public String deleteItem(@RequestParam(name="id", defaultValue = "0") Long id){

        Users user=userService.findById(id);
        if(user!=null){
            userService.deleteUser(user);
        }

        return "redirect:/";
    }

    @GetMapping(value="/adduser")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    public String addUser(Model model){

        List<Roles>  roles=userService.findAllRoles();
        model.addAttribute("roles", roles);

        model.addAttribute("currentUser", getUserData());
        return "adduser";
    }

    @PostMapping(value="/adduser")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    public String addUserByAdmin(@RequestParam(name="id", defaultValue = "0") Long id,
                           @RequestParam(name="user_email", defaultValue = "No User") String email,
                           @RequestParam(name="user_name", defaultValue = "No User") String name,
                           @RequestParam(name="user_password", defaultValue ="No password") String password,
                           @RequestParam(name="roles_id",defaultValue = "0") Long role_id){

        Users user=new Users();
        user.setFullName(name);
        user.setEmail(email);
        user.setPassword(password);
        List<Roles> rolesList=new ArrayList<>();
        Roles role=userService.findRoleById(role_id);

        if(role!=null) {
            rolesList.add(role);
            user.setRoles(rolesList);
            userService.saveUser(user);
        }


        return "redirect:/modify";
    }

//    @PostMapping(value="/search")
//    public Users addUserByAdmin(@RequestParam(name="user_name", defaultValue = "No User") String name){
//        Users users=userService.findUserByUsername(name);
//
//
//
//        return users;
//    }



    @GetMapping(value="/login")
    public String logout1(Model model){
        model.addAttribute("currentUser", getUserData());
        return "login";
    }

    private Users getUserData(){
        Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
        if(!(authentication instanceof AnonymousAuthenticationToken)){
            User secUser=(User)authentication.getPrincipal();
            Users myUser=userService.getUserByEmail(secUser.getUsername());
            return myUser;
        }

        return null;
    }
}
